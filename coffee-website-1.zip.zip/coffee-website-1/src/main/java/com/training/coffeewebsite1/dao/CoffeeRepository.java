package com.training.coffeewebsite1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.coffeewebsite1.bean.CoffeeBean;

public interface CoffeeRepository extends JpaRepository<CoffeeBean, Integer> {

}
