package com.training.coffeewebsite1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeWebsite1Application {

	public static void main(String[] args) {
		SpringApplication.run(CoffeeWebsite1Application.class, args);
	}

}
