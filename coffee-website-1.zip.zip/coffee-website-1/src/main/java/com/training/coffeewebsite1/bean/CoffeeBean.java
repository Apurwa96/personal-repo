package com.training.coffeewebsite1.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table
public class CoffeeBean {

	@Id
	//defining Order ID as column name
	@Column
	private int orderid;
	//defining Coffee Type as column name
	@Column
	private String coffeetype;
	//defining Price as column name
	@Column
	private double price;
	//defining Customer Name as column name
	@Column
	private String customername;
	
	public int getOrderId() 
	{
	return orderid;
	}
	public void setOrderId(int orderid) 
	{
	this.orderid = orderid;
	}
	public String getCoffeeType() 
	{
	return coffeetype;
	}
	public void setCoffeeType(String coffeetype) 
	{
	this.coffeetype = coffeetype;
	}
	public double getPrice() 
	{
	return price;
	}
	public void setAge(double price) 
	{
	this.price = price;
	}
	public String getCustomerName() 
	{
	return customername;
	}
	public void setCustomerName(String customername) 
	{
	this.customername = customername;
	}


}
