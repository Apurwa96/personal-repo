package com.training.coffeewebsite1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.coffeewebsite1.bean.CoffeeBean;
import com.training.coffeewebsite1.dao.CoffeeRepository;

@Service
public class CoffeeServiceImpl implements CoffeeService {

	private CoffeeRepository coffeeRepository;
	
	@Autowired
	public CoffeeServiceImpl(CoffeeRepository coffeeRepository) {
		// TODO Auto-generated constructor stub
		this.coffeeRepository=coffeeRepository;
	}
	
	@Override
	public List<CoffeeBean> findAllOrders() {
		// TODO Auto-generated method stub
		return coffeeRepository.findAll();
	}

	@Override
	public CoffeeBean findByOrderId(int orderid) {
		// TODO Auto-generated method stub
		
		Optional<CoffeeBean> result = coffeeRepository.findById(orderid);
		
		CoffeeBean coffee = null;
		
		if (result.isPresent()) {
			coffee = result.get();
		}
		else {
			// we didn't find the employee
			throw new RuntimeException(" coffee order no. - " + orderid + "not found.");
		}
		
		return coffee;
	}

	@Override
	public void updateOrder(CoffeeBean coffee) {
		// TODO Auto-generated method stub
		coffeeRepository.save(coffee);	
	}

	@Override
	public void deleteByOrderId(int orderid) {
		// TODO Auto-generated method stub
		coffeeRepository.deleteById(orderid);
	}
	
	

}
