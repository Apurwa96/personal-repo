package com.training.coffeewebsite1.service;

import java.util.List;

import com.training.coffeewebsite1.bean.CoffeeBean;


public interface CoffeeService {
	
	public List<CoffeeBean> findAllOrders();
	
	public CoffeeBean findByOrderId(int orderid);
	
	public void updateOrder(CoffeeBean coffee);
	
	public void deleteByOrderId(int orderid);

}
