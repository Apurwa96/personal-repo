package com.training.coffeewebsite1.controller;

import java.util.List;
import java.util.Map;
import java.util.Random;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.training.coffeewebsite1.bean.CoffeeBean;
import com.training.coffeewebsite1.dao.CoffeeRepository;
import com.training.coffeewebsite1.service.CoffeeService;


@RestController
public class CoffeeController {

	private CoffeeService coffeeService;

	@Autowired
	public CoffeeController(CoffeeService coffeeService) {
		// TODO Auto-generated constructor stub
		this.coffeeService = coffeeService;
	}

	// List all orders
	
//	  @GetMapping("/coffee")
//	  public List<CoffeeBean> findAll() 
//	  {
//		  return coffeeService.findAll();
//	}
	 
	
	/*
	 * @GetMapping("/coffee") public String findAll(Model theModel) {
	 * theModel.addAttribute("coffeeOrders",coffeeService.findAll()); return
	 * "list-orders"; }
	 */
	
	@GetMapping("/coffee")
	public ModelAndView findAll() {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.addObject("coffeeOrders",coffeeService.findAllOrders());
	    modelAndView.setViewName("list-orders");
	    return modelAndView;
	}
	
	@RequestMapping("/")
	public ModelAndView index () {
	    ModelAndView modelAndView = new ModelAndView();
	    modelAndView.setViewName("index");
	    return modelAndView;
	}
	
	 @GetMapping("/coffee/{orderid}") 
	 public ModelAndView getCoffeeOrder(@PathVariable("orderid") int orderid) 
	 {
		 ModelAndView modelAndView = new ModelAndView();
	 CoffeeBean coffee = coffeeService.findByOrderId(orderid); 
	 if (coffee == null)
	 { 
		 throw new RuntimeException(" coffee order no. - " + orderid + "not found."); 
	 } 
	 modelAndView.addObject("OrderByID", coffee); 
	 modelAndView.setViewName("list-orders");
	 return modelAndView; 
	 }
	


}
